#ifndef __LIBCGI_H__
#define __LIBCGI_H__

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <winbase.h>
#include <commctrl.h>
#define char_t wchar_t



#ifdef __cplusplus
extern "C" {
#endif

int init(int argc, _TCHAR* argv[]);
void destroy();
int write_data(const char_t *fmt,...);
char_t* gogetenv(char_t *key,char_t *value);

#ifdef __cplusplus
}
#endif
#endif