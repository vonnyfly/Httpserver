#include "libcgi.h"

HANDLE hOut;
FILE* fin;
//ok:return value;else return null
char_t* gogetenv(char_t *key,char_t *value)
{
    char_t* pos=NULL;
    char_t buf[256];
    int bSuccess;
    
    if (fin) {
		fseek(fin,0,SEEK_SET);
        while (fgetws((wchar_t*)buf, 256, fin)) { // Key & Value
            pos = wcschr(buf, L'=');
            if (!pos) {
                continue;
            }
            *pos = L'\0'; // Erase the '='
            if (0 != _wcsicmp(buf, key)) { // Key
                continue;
            }
            pos++; // Point to the value
            bSuccess = SUCCEEDED(StringCchCopy(value,256,pos));
            if(bSuccess) {                
                return value;
            }
        }
    }
    return NULL;
}

int init(int argc, _TCHAR* argv[])
{
    char_t buf[256];
    hOut = CreateFile(argv[argc-1], GENERIC_WRITE, FILE_SHARE_WRITE, NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL, NULL);
    if(hOut == INVALID_HANDLE_VALUE)
        return -1;
    write_data(L"Content-type:text/html;charset=gbk\r\n\r\n");
    write_data(L"<TITLE>CGI</TITLE><H3>CGI environment</H3>");

	fin = _wfopen(argv[argc-2], L"rb");
    return 1;
}
void destroy()
{
    CloseHandle(hOut);
	fclose(fin);
}

int write_data(const char_t *fmt,...)
{
    va_list		args;
    char_t		buf[256];
    int need_write,written;

    va_start(args, fmt);
    need_write = vswprintf(buf,fmt,args);
    va_end(args);
    WriteFile(hOut,buf,2*need_write,(LPDWORD)&written,NULL) ;
#ifdef D_DEBUG
    wprintf(L"%s| sizeof: %d need write:%d written: %d wcslen: %d\n",buf,sizeof(buf),need_write,written,wcslen(buf));
#endif
    return written;
}